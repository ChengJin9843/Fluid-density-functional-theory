### 编译命令
```sh
ifort -O2 dft.f90 -o DFT
gfortran -O2 dft.f90 -o DFT
```