#include "sysapi.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>


void getCmdsFromArgs(Cmds& commands, int argc, char* argv[])
{
    // start from 1 cause first argv is cdft.exe
    for (int i = 1; i < argc; i++)
    {
        std::string cmd = std::string(argv[i]);

        if (cmd == "-i" || cmd == "--input")
        {
            i++;
            if (i < argc)
            {
                commands.input = std::string(argv[i]);
            }
            else
            {

            }
        }

        else if (cmd == "-e" || cmd == "--execute")
        {
            i++;
            if (i < argc)
            {
                commands.exe = std::string(argv[i]);
            }
            else
            {

            }
        }
    }

    if (commands.exe == "")
    {
        commands.exe = getExecuteDirectory() + PATH_SEP + DFT;
    }
}

int subprocesss(const char* commands)
{
    int error = 0;
#ifdef _WIN32
    BOOL bIsProcessInJob;
    BOOL bSuccess = IsProcessInJob(GetCurrentProcess(), NULL, &bIsProcessInJob);
    if (bSuccess == 0) {
        printf("IsProcessInJob failed: error %d\n", GetLastError());
        return -1;
    }

    if (bIsProcessInJob) {
        //printf("Process is already in Job\n");
    }
    HANDLE hJob = CreateJobObject(NULL, NULL);
    if (hJob == NULL) {
        printf("CreateJobObject failed: error %d\n", GetLastError());
        return -1;
}
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION jeli = { 0 };
    jeli.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;

    bSuccess = SetInformationJobObject(hJob, JobObjectExtendedLimitInformation, &jeli, sizeof(jeli));
    if (bSuccess == 0) {
        printf("SetInformationJobObject failed: error %d\n", GetLastError());
        return -1;
    }

    DWORD dwCreationFlags = bIsProcessInJob ? CREATE_BREAKAWAY_FROM_JOB : 0;

    STARTUPINFO si = { 0 };
    PROCESS_INFORMATION pi = { 0 };

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));


    // convert string to wchar_t*;

    //std::cout << commands << std::endl;
    int num = ::MultiByteToWideChar(CP_ACP, 0, commands, -1, NULL, 0);
    wchar_t* wide = new wchar_t[num];
    ::MultiByteToWideChar(CP_ACP, 0, commands, -1, wide, num);

    bSuccess = CreateProcess(NULL,   // No module name (use command line)
        wide,           // Command line
        NULL,           // Process handle not inheritable
        NULL,           // Thread handle not inheritable
        FALSE,          // Set handle inheritance to FALSE
        dwCreationFlags,              // No creation flags
        NULL,           // Use parent's environment block
        NULL,           // Use parent's starting directory 
        &si,            // Pointer to STARTUPINFO structure
        &pi);           // Pointer to PROCESS_INFORMATION structure

    delete[]wide;

    if (!bSuccess)
    {
        printf("CreateProcess failed (%d).\n", GetLastError());
        return -1;
    }


    bSuccess = AssignProcessToJobObject(hJob, pi.hProcess);
    if (bSuccess == 0) {
        printf("AssignProcessToJobObject failed: error %d\n", GetLastError());
        return -1;
    }
    // Start the child process. 


    // Wait until child process exits.
    WaitForSingleObject(pi.hProcess, INFINITE);

    DWORD exitCode = 0;
    GetExitCodeProcess(pi.hProcess, &exitCode);

    // Close process and thread handles. 
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    error = exitCode;
    CloseHandle(hJob);
#else
    char path[512];

    FILE* fp = popen(commands, "r");
    if (fp == NULL)
    {
    }

    while (fgets(path, 512, fp) != NULL)
    {
        printf("%s", path);
    }

    error = pclose(fp);
#endif
    return error;
}


bool createDirectory(const std::string& folder)
{
    std::string folder_builder;
    std::string sub;
    sub.reserve(folder.size());
    for (auto it = folder.begin(); it != folder.end(); ++it)
    {
        //cout << *(folder.end()-1) << endl;
        const char c = *it;
        sub.push_back(c);
        if (c == PATH_SEP || it == folder.end() - 1)
        {
            folder_builder.append(sub);
#ifdef _WIN32
            if (0 != ::_access(folder_builder.c_str(), 0))
            {
                // this folder not exist
                if (0 != ::_mkdir(folder_builder.c_str()))
                {
                    // create failed
                    return false;
                }
            }
#else
            std::string cmdline = "mkdir -p " + folder_builder;
            subprocesss(cmdline.c_str());
#endif
            sub.clear();
        }
    }
    return true;
}

bool setWorkingDirectory(const char* dir) { return CHDIR(dir) == 0; }

std::string GetCurrentWorkingDirectory()
{
    const int BUFSIZE = 4096;
    char buf[BUFSIZE];
    memset(buf, 0, BUFSIZE);
    GETCWD(buf, BUFSIZE - 1);
    return buf;
}

std::string getExecuteDirectory()
{
#ifdef _WIN32
    wchar_t buffer[MAX_PATH];
    GetModuleFileName(NULL, buffer, MAX_PATH);

    int num = ::WideCharToMultiByte(CP_ACP, 0, buffer, -1, NULL, 0, NULL, FALSE);
    char* c = new char[num];
    ::WideCharToMultiByte(CP_ACP, 0, buffer, -1, c, num, NULL, FALSE);

    std::string exe_path = c;
    delete[]c;
#else
    char buffer[PATH_MAX];
    ssize_t count = readlink("/proc/self/exe", buffer, PATH_MAX);
    std::string exe_path(buffer, (count > 0) ? count : 0);
#endif

    std::string::size_type pos = exe_path.find_last_of(PATH_SEP);

    return exe_path.substr(0, pos);
}
