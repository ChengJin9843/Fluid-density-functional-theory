# CDFT mpi control code

## Code 

### 命令行参数

-i arg 表明CDFT调度器使用的输入参数文件

-e arg 表明CDFT调度器使用的软件路径

## 编译器
支持的语言标准**C++ 11**及其以上，支持以下：

### 编译命令
```sh
icc -std=c++11 main.cpp core.cpp sysapi.cpp read.cpp -I./ -lmpi -O2 -o CDFT
g++ -std=c++11 main.cpp core.cpp sysapi.cpp read.cpp -I./ -lmpi -O2 -o CDFT
```
## 软件说明
CDFT mpi调度器 主要实现的功能

1. 读入CDFT参数生成参数扫描的空间；

2. mpirun 并行调度 调用-e arg这个软件使得每个进程分配一个计算任务；

3. 所有任务计算结束后，回收数据。
