#include "core.h"
#include "sysapi.h"
#include "mpi.h"

#include <fstream>


std::string trim(std::string s, std::string flag)
{
    if (s.empty())
    {
        return s;
    }
    s.erase(0, s.find_first_not_of(flag));
    s.erase(s.find_last_not_of(flag) + 1);
    return s;
}

std::vector<std::string> split(const std::string& string, const std::string flag)
{
    std::string::size_type pos;
    std::vector<std::string> result;
    std::string str = string + flag;//扩展字符串以方便操作
    size_t size = str.size();

    for (size_t i = 0; i < size; i++)
    {
        pos = str.find(flag, i);
        if (pos < size)
        {
            std::string s = str.substr(i, pos - i);
            if (trim(s, flag) == "")
            {
                continue;
            }
            result.push_back(trim(s, flag));
            i = pos + flag.size() - 1;
        }
    }
    return result;
}

std::string getDir(const std::string& datai)
{
    std::string dir = "";
    for (auto item : split(datai, " "))
    {
        dir += item + "_";
    }
    return dir.substr(0, dir.size() - 1);
}

std::string getCmd(const std::string& datai)
{
    std::string cmd = "";
    for (auto item : split(datai, " "))
    {
        if (item.find("RHOB") != std::string::npos) cmd += " -" + item;
        else cmd += " " + item;
    }
    return cmd.substr(1);
}

void cdftRun(std::vector<std::string>& data, Cmds& command)
{   
    // get number of all processes 
    int size;
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    
    // get process rank
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);


    for (size_t i = 0; i < data.size(); ++i)
    {
        if((i + 1)%size == rank)
        {          
            // get current path
            std::string wpath = GetCurrentWorkingDirectory();

            // create Directory
            std::string newWorkPath = wpath + PATH_SEP + "data" + PATH_SEP + getDir(data[i]);
            createDirectory(newWorkPath);

            // set working Directory
            setWorkingDirectory(newWorkPath.c_str());

            // run dft
            std::string command_line = command.exe + " -in " + command.input + " " + getCmd(data[i]);
            subprocesss(command_line.c_str());
            
            setWorkingDirectory(wpath.c_str());
        //    std::cout << "node: " << rank <<" work: " << i << std::endl;
        //    std::string wpath = GetCurrentWorkingDirectory();
 
        //    std::string setPath = wpath + "/" +std::to_string(i - 1) + "/";
        //    setWorkingDirectory(setPath.c_str());
        //    std::cout << "workpath: " << wpath << std::endl;
        //    std::cout << "setPath: " << setPath <<std::endl;
        //    std::string command = wpath +"/a.out >log";
        //    subprocesss(command.c_str());
 
        //    setWorkingDirectory(wpath.c_str());         
        //    //std::cout << "node: " << rank <<" work: " << i << std::endl;
        }
    }
  
    MPI_Barrier(MPI_COMM_WORLD);
}

int getAllData(std::vector<std::string>& data, std::vector<std::string>files)
{
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    if (rank == 0)
    {
        std::string wpath = GetCurrentWorkingDirectory();
        createDirectory(wpath + PATH_SEP + "alldata");

        for (size_t j = 0; j < files.size(); ++j)
        {
            std::ofstream out(wpath + PATH_SEP + "alldata" + PATH_SEP + files[j]);

            for (size_t i = 0; i < data.size(); ++i)
            {
                out << "START: " << data[i] << std::endl;

                std::ifstream in(wpath + PATH_SEP + "data" + PATH_SEP + getDir(data[i]) + PATH_SEP + files[j] + "_psi0_  1.00");
                out << in.rdbuf();

                out << "END" << std::endl;

                in.close();
            }

            out.close();
        }
    }
    MPI_Barrier(MPI_COMM_WORLD);

    return 0;
}
