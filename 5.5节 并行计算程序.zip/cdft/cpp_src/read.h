#pragma once
#include <string>
#include <vector>
enum class ScanType{All, Target};
struct STEPInfo
{
    double start = 0;
    double end = 0;
    double step = 0;
};

int getDataFromFile(std::vector<std::string>& data, std::string file = "./dft.input");