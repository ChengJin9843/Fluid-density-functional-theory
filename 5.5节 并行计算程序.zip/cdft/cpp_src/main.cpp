#include "sysapi.h"

#include <iostream>
#include <vector>

#include "core.h"
#include "mpi.h"
#include "read.h"

int main(int argc, char* argv[])
{
    // get input file path
    Cmds command;
    getCmdsFromArgs(command, argc, argv);

    // initialize mpi
    MPI_Init(&argc, &argv);
    std::cout << "Initialize mpi done!" << std::endl;
    
    // read input file and get possible parameters
    std::vector<std::string> data;
    getDataFromFile(data, command.input);
    std::cout << "Read parameters done!" << std::endl;

    // run mpi task
    cdftRun(data, command);
    std::cout << "Run mpi done!" << std::endl;

    // get all data
    getAllData(data);
    std::cout << "Get all data done!" << std::endl;

    MPI_Finalize();

    return 0;
}