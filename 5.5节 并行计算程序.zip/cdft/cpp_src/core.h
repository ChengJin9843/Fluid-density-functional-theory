#pragma once
#include <vector>
#include <string>
#include "sysapi.h"


#ifdef _WIN32
#define PATH_SEP '\\'
#else
#define PATH_SEP '/'
#endif


void cdftRun(std::vector<std::string>& data, Cmds& command);

int getAllData(std::vector<std::string>& data, std::vector<std::string>files={"CIMEP", "PARAMETER", "PROFILE"});