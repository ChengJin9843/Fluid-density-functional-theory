#include "read.h"
#include <map>
#include <fstream>
#include <sstream>
#include <iostream>


std::string getKey(const std::string& line)
{
    std::string tmp_str;
    tmp_str = line.substr(line.find("!") + 1);
    tmp_str = tmp_str.substr(tmp_str.find_first_not_of(" "));
    tmp_str = tmp_str.substr(0, tmp_str.find(".range"));
    return tmp_str;
}

int read(std::string& file, ScanType& st, std::map<std::string, STEPInfo>& paras)
{
    std::ifstream in(file);
    if(!in.is_open())
    {

    } 

    std::string line;
    //double start, end, step;


    while(std::getline(in, line))
    {
        if(line.find("ScanType")!=std::string::npos)
        {
            std::getline(in, line);
            int type = std::atoi(line.c_str());
            if(type == 0) st =ScanType::All;
            else st =ScanType::Target;

            //std:: cout << line << std::endl;
            continue;
        }

        if(line.find(".range")!=std::string::npos)
        {
            //std::cout << line << std::endl;
            STEPInfo sinfo;

            std::string key = getKey(line);

            std::getline(in, line);
            std::stringstream ss(line);
            ss >>sinfo.start >> sinfo.end;

            //std::cout << key << sinfo.start << sinfo.end << std::endl;
            // get step
            std::getline(in, line);
            std::getline(in, line);
            sinfo.step = std::atof(line.c_str());

            paras[key]= sinfo;
            continue;
        }
    }
    return 0;
}

int getTarget(std::vector<std::string>&v, std::map<std::string, STEPInfo>& paras)
{

    auto iter = paras.begin();

    int N = int((iter->second.end - iter->second.start) / iter->second.step) + 1;

    for(int i=0; i<N;++i)
    {
        std::string s = "";
        for(auto x: paras)
        {
            double value = x.second.start + i* x.second.step;
            s += " " + x.first + " " + std::to_string(value);
        }

        v.push_back(s);
    }

    return 0;

}

int getALL(std::vector<std::string>&v, std::vector<std::string>&v2, const std::string&key, STEPInfo& si)
{
    for(auto x: v)
    {
        int N = int((si.end - si.start) / si.step) + 1;
        for (int i = 0; i < N; ++i)
        {
            double value = si.start + i * si.step;
            std::string s = x + " " + key + " " + std::to_string(value);
            v2.push_back(s);
        }
        //for (double value = si.start; value <= si.end; value += si.step)
        //{
        //    std::string s = x +  " " + key + " " + std::to_string(value);
        //    v2.push_back(s);
        //}
    }
    return 0;
}

int getAllParas(std::vector<std::string>& data, std::map<std::string, STEPInfo>& paras, ScanType type)
{
    if(type == ScanType::Target)
    {
        //std::cout << "target "<< std::endl;
        getTarget(data, paras);
    }
    else
    {
        //std::cout << "all" << std::endl;
        std::vector<std::string> v2;
        data.resize(1);
        data[0] = "";
        for(auto x: paras)
        {
            getALL(data, v2,  x.first, x.second);
            data = v2;
            v2.clear();
        }
    }
    return 0;
}


int getDataFromFile(std::vector<std::string>& data, std::string file)
{
    ScanType st;
    std::map<std::string, STEPInfo> paras;
    read(file, st, paras);

    data.clear();
    getAllParas(data, paras, st);

    
    //for(auto x: data)
    //{
    //    std::cout << x << std::endl;
    //}

    return 0;
}

