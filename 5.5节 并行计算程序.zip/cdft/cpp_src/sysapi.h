#pragma once
#include <string>


#ifdef _WIN32
#include <Windows.h>
#include "direct.h"
#include <io.h>
#define PATH_SEP '\\'
#define GETCWD _getcwd
#define CHDIR _chdir
#define DFT "dft.exe"
#else
#include <limits.h>
#include <unistd.h>
#define PATH_SEP '/'
#define GETCWD getcwd
#define CHDIR chdir
#define DFT "dft"
#endif //_Win32


struct Cmds
{
    std::string input = "./dft.input";
    std::string exe = "";
};

void getCmdsFromArgs(Cmds& commands, int argc, char* argv[]);

int subprocesss(const char* commands);

bool createDirectory(const std::string& folder);

bool setWorkingDirectory(const char* dir);

std::string GetCurrentWorkingDirectory();

std::string getExecuteDirectory();
